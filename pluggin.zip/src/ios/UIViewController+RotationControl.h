
//  UIViewController+RotationControl.h
//  TestPlayer
//
//  Created by BlueDancer on 2019/8/28.
//  Copyright © 2019 SanJiang. All rights reserved.


#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface UIViewController (RotationControl)

@end

NS_ASSUME_NONNULL_END
